from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter

# ------------------------------------------------------------
# user choices
# ------------------------------------------------------------
BASE = Path("/home/idies/workspace/Storage/elenceq/mhd_work/jhtdb_mhd1024")
RAW = BASE / "raw"
OUT = BASE / "processed" / "Cl_new15_smoketest"
OUT.mkdir(parents=True, exist_ok=True)

stem = "t0022_x321-640_y641-960_z641-960"   # C06 smoke test
ell_grid = [32, 64, 128, 192]              # smoke test first
comp_map = [2, 1, 0]                       # same convention as before

# ------------------------------------------------------------
# load data
# ------------------------------------------------------------
u0 = np.load(RAW / f"mhd1024_velocity_{stem}.npy")
b0 = np.load(RAW / f"mhd1024_magneticfield_{stem}.npy")
p0 = np.load(RAW / f"mhd1024_pressure_{stem}.npy")

u = u0[..., comp_map].astype(np.float64, copy=False)
b = b0[..., comp_map].astype(np.float64, copy=False)
p = p0.astype(np.float64, copy=False)

print("loaded:")
print("  u:", u.shape)
print("  b:", b.shape)
print("  p:", p.shape)

assert u.shape == b.shape
assert p.shape == u.shape[:3]

# ------------------------------------------------------------
# helpers
# ------------------------------------------------------------
def filt_scalar(f, ell):
    # Gaussian chosen so its second moment matches a box filter of width ell
    sigma = ell / np.sqrt(12.0)
    return gaussian_filter(f, sigma=sigma, mode="wrap")

def filt_vec(v, ell):
    out = np.empty_like(v)
    for c in range(3):
        out[..., c] = filt_scalar(v[..., c], ell)
    return out

def ddx(f):
    # x is axis 2
    return 0.5 * (np.roll(f, -1, axis=2) - np.roll(f, 1, axis=2))

def ddy(f):
    # y is axis 1
    return 0.5 * (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1))

def ddz(f):
    # z is axis 0
    return 0.5 * (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0))

def grad_scalar(f):
    # returns (..., 3) in x,y,z order
    return np.stack([ddx(f), ddy(f), ddz(f)], axis=-1)

def jacobian_vec(v):
    # v[..., i], grad wrt x,y,z -> J[..., i, j]
    J = np.empty(v.shape[:3] + (3, 3), dtype=np.float64)
    for i in range(3):
        J[..., i, 0] = ddx(v[..., i])
        J[..., i, 1] = ddy(v[..., i])
        J[..., i, 2] = ddz(v[..., i])
    return J

def advect(a, v):
    # (a · ∇) v, with a,v shape (...,3)
    Jv = jacobian_vec(v)
    return np.einsum("...j,...ij->...i", a, Jv)

def lipschitz_from_field(F):
    # approximate sup_x ||∇F(x)||_F
    J = jacobian_vec(F)
    return float(np.max(np.sqrt(np.sum(J**2, axis=(-2, -1)))))

# ------------------------------------------------------------
# exact-grid smoke test
# ------------------------------------------------------------
results = []

for ell in ell_grid:
    print(f"\nprocessing ell = {ell}")

    # coarse-grained fields
    u_ell = filt_vec(u, ell)
    b_ell = filt_vec(b, ell)

    zplus_ell  = u_ell + b_ell
    zminus_ell = u_ell - b_ell

    # total pressure used in Elsasser form
    Pi = p + 0.5 * np.sum(b * b, axis=-1)
    Pi_ell = filt_scalar(Pi, ell)
    gradPi_ell = grad_scalar(Pi_ell)

    # G^\pm = (z^\pm - z^\mp)·∇ z^\pm - ∇Pi = 2 (b_ell·∇) z^\pm - ∇Pi
    G_plus  = 2.0 * advect(b_ell, zplus_ell)  - gradPi_ell
    G_minus = 2.0 * advect(b_ell, zminus_ell) - gradPi_ell

    C_plus = lipschitz_from_field(G_plus)
    C_minus = lipschitz_from_field(G_minus)
    C_avg = 0.5 * (C_plus + C_minus)

    print(f"  C_plus  = {C_plus:.6e}")
    print(f"  C_minus = {C_minus:.6e}")
    print(f"  C_avg   = {C_avg:.6e}")

    results.append({
        "ell": int(ell),
        "C_plus": C_plus,
        "C_minus": C_minus,
        "C_avg": C_avg,
    })

# ------------------------------------------------------------
# save json
# ------------------------------------------------------------
json_path = OUT / f"Cl_smoketest_{stem}.json"
with open(json_path, "w") as f:
    json.dump({
        "stem": stem,
        "ell_grid": ell_grid,
        "definition": "C_ell^± approximated by max Frobenius norm of Jacobian of G_ell^± on the exact grid",
        "Pi_used": "p + |b|^2/2",
        "filter": "periodic Gaussian with sigma = ell/sqrt(12)",
        "results": results,
    }, f, indent=2)

print("\nsaved json:")
print(" ", json_path)

# ------------------------------------------------------------
# plot
# ------------------------------------------------------------
ells = np.array([r["ell"] for r in results], dtype=float)
Cp = np.array([r["C_plus"] for r in results], dtype=float)
Cm = np.array([r["C_minus"] for r in results], dtype=float)
Ca = np.array([r["C_avg"] for r in results], dtype=float)

fig, ax = plt.subplots(figsize=(6.4, 4.8))
ax.loglog(ells, Cp, marker="o", label=r"$C_\ell^+$")
ax.loglog(ells, Cm, marker="s", label=r"$C_\ell^-$")
ax.loglog(ells, Ca, marker="d", label=r"$C_\ell$ average")
ax.set_xlabel(r"scale $\ell$")
ax.set_ylabel(r"$C_\ell$")
ax.set_title(f"320^3 smoke test: {stem}")
ax.legend(frameon=False)
fig.tight_layout()

png_path = OUT / f"Cl_smoketest_{stem}.png"
pdf_path = OUT / f"Cl_smoketest_{stem}.pdf"
fig.savefig(png_path, dpi=220, bbox_inches="tight")
fig.savefig(pdf_path, bbox_inches="tight")
plt.show()

print("saved:")
print(" ", png_path)
print(" ", pdf_path)