# Minimal reproducibility bundle: geometric and stochastic diagnostics

Generated: 2026-04-28T13:53:00

This bundle contains the minimal files needed to reproduce the geometric-fragility
and stochastic angle--amplitude parts of the manuscript, without storing the raw
JHTDB cutouts.

## Contents

- `metadata/`
  - `new15_320_cube_metadata.json`: final 15 non-overlapping 320^3 cubes.
  - `reference_448_cube_metadata.json`: larger 448^3 reference cube.

- `scripts/`
  - Scripts used for the compact-support geometric diagnostic, stochastic
    angle--amplitude diagnostic, aggregation, and plotting. Some plotting
    scripts may have been generated from notebook cells; check the manifest.

- `processed/fragile_alignment_exact_320/`
  - Per-cube JSON outputs for the geometric control coefficient and stochastic
    angle--amplitude diagnostics.
  - Ensemble JSON/CSV summaries.

- `processed/physical_angle_products_ensemble15_sine_only_SEM/`
  - Data and figure inputs for the introduction sine-proxy/covariance plot.

- `figures/`
  - PDF figures used or intended for the manuscript.

## Raw data

The raw velocity, magnetic-field, and pressure cutouts are not included.
They are public JHTDB `mhd1024` cutouts and can be regenerated from the
metadata files.

## Notes

The geometric continuity-control diagnostic uses the pressure field through
the coarse-grained total pressure. The angle, cross-scale, and stochastic
diagnostics use only velocity and magnetic field data.
